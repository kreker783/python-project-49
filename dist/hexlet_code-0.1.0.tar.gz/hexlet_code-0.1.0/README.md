### Hexlet tests and linter status:
[![Actions Status](https://github.com/kreker783/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/kreker783/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/98a66742fa8f947a25f3/maintainability)](https://codeclimate.com/github/kreker783/python-project-49/maintainability)

Brain-even game demo:
https://asciinema.org/a/603130


Brain-calc game demo:
https://asciinema.org/a/603219


Brain-gcd game demo:
https://asciinema.org/a/vTc4NUpUrk6MkNlvmPYr3Plsb


Brain-progression game demo:
https://asciinema.org/a/BiSEzXpmWTiZzuhhAyjZmTXkj


Brain-prime game demo:
https://asciinema.org/a/VjdEVH5vFtQWpJZNl3GVjVrTo
